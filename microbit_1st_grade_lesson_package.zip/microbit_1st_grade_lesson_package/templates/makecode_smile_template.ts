// MakeCode (TypeScript) template: ニコちゃん点滅
// 手順: MakeCode の「JavaScript」タブにこのコードを貼り付け、"Download" で .hex を取得してください。

basic.forever(function () {
    basic.showIcon(IconNames.Happy)
    basic.pause(500)
    basic.clearScreen()
    basic.pause(300)
})
